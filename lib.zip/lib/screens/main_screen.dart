import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'orders_screen.dart';
import 'values_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  // Lista das telas que a BottomNavigationBar irá controlar
  static final List<Widget> _widgetOptions = <Widget>[
    const OrdersScreen(),
    const ValuesScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  String _getTitleForIndex(int index) {
    switch (index) {
      case 0:
        return 'Vó Naná - Pedidos';
      case 1:
        return 'Vó Naná - Configurações de Valores';
      default:
        return 'Vó Naná';
    }
  }

  @override
  Widget build(BuildContext context) {

    final bottomNavTheme = Theme.of(context).bottomNavigationBarTheme;

    return Scaffold(

      appBar: AppBar(
        title: Text(_getTitleForIndex(_selectedIndex)),
        actions: [
          // Logout button
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.of(context).pushReplacementNamed('/login');
            },
          ),
        ],
      ),

      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: Container(

        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
          ),

          child: BottomNavigationBar(

            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.list_alt_rounded),
                label: 'Pedidos',
              ),

              BottomNavigationBarItem(
                icon: Icon(Icons.settings_suggest_rounded),
                label: 'Valores',
              ),
            ],

            currentIndex: _selectedIndex,
            onTap: _onItemTapped,
          ),
        ),
      ),
    );
  }
}