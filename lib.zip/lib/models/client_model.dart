import 'package:cloud_firestore/cloud_firestore.dart';

class Client {
  final String whatsappId;
  final String shippingAddress;

  Client({
    required this.whatsappId,
    required this.shippingAddress,
  });

  factory Client.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Client(
      whatsappId: doc.id,
      shippingAddress: data['shippingAddress'] ?? 'N/A',
    );
  }
}