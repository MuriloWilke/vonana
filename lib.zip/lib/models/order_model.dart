import 'package:cloud_firestore/cloud_firestore.dart';

class OrderModel {
  final String id;
  final String clientId;
  final Timestamp creationDate;
  final int dozens;
  final String paymentMethod;
  final String deliveryStatus;
  final String shippingAddress;
  final int total;

  OrderModel({
    required this.id,
    required this.clientId,
    required this.creationDate,
    required this.dozens,
    required this.paymentMethod,
    required this.deliveryStatus,
    required this.shippingAddress,
    required this.total,
  });

  factory OrderModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return OrderModel(
      id: doc.id,
      clientId: data['clientId'] ?? 'N/A',
      creationDate: data['creationDate'] as Timestamp? ?? Timestamp.now(),
      dozens: data['dozens'] ?? 0,
      paymentMethod: data['paymentMethod'] ?? 'Pix',
      deliveryStatus: data['deliveryStatus'] ?? 'Unknown',
      shippingAddress: data['shippingAddress'] ?? 'N/A',
      total: data['total'] ?? 0,
    );
  }
}