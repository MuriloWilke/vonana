import 'package:cloud_firestore/cloud_firestore.dart';

// Modelo para cada item dentro do pedido
class OrderItemModel {
  final int itemValue;
  final int quantity;
  final String type;

  OrderItemModel({
    required this.itemValue,
    required this.quantity,
    required this.type,
  });

  factory OrderItemModel.fromMap(Map<String, dynamic> map) {
    return OrderItemModel(
      itemValue: map['itemValue'] ?? 0,
      quantity: map['quantity'] ?? 0,
      type: map['type'] ?? 'N/A',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'itemValue': itemValue,
      'quantity': quantity,
      'type': type,
    };
  }
}

// Modelo para o endereço de entrega
class ShippingAddressModel {
  final String? adminArea;
  final String? businessName;
  final String? city;
  final String? country;
  final String? island;
  final String? shortcut;
  final String? streetAddress;
  final String? subadminArea;
  final String? zipCode;

  ShippingAddressModel({
    this.adminArea,
    this.businessName,
    this.city,
    this.country,
    this.island,
    this.shortcut,
    this.streetAddress,
    this.subadminArea,
    this.zipCode,
  });

  factory ShippingAddressModel.fromMap(Map<String, dynamic> map) {
    return ShippingAddressModel(
      adminArea: map['admin-area'],
      businessName: map['business-name'],
      city: map['city'],
      country: map['country'],
      island: map['island'],
      shortcut: map['shortcut'],
      streetAddress: map['street-address'],
      subadminArea: map['subadmin-area'],
      zipCode: map['zip-code'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'admin-area': adminArea,
      'business-name': businessName,
      'city': city,
      'country': country,
      'island': island,
      'shortcut': shortcut,
      'street-address': streetAddress,
      'subadmin-area': subadminArea,
      'zip-code': zipCode,
    };
  }

  @override
  String toString() {
    List<String> parts = [];
    if (businessName != null && businessName!.isNotEmpty) parts.add(businessName!);
    if (streetAddress != null && streetAddress!.isNotEmpty) parts.add(streetAddress!);
    if (city != null && city!.isNotEmpty) parts.add(city!);
    return parts.join(', ');
  }
}

// Modelo de Pedido
class OrderModel {
  final String id;
  final String clientId;
  final Timestamp creationDate;
  final Timestamp? deliveryDate;
  final String deliveryStatus;
  final List<OrderItemModel> items;
  final String paymentMethod;
  final ShippingAddressModel shippingAddress;
  final int shippingCost;
  final int total;
  final int totalDozens;

  OrderModel({
    required this.id,
    required this.clientId,
    required this.creationDate,
    this.deliveryDate,
    required this.deliveryStatus,
    required this.items,
    required this.paymentMethod,
    required this.shippingAddress,
    required this.shippingCost,
    required this.total,
    required this.totalDozens,
  });

  factory OrderModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    // Tratamento para o array de items
    List<OrderItemModel> orderItems = [];
    if (data['items'] != null && data['items'] is List) {
      orderItems = (data['items'] as List)
          .map((itemData) =>
          OrderItemModel.fromMap(itemData as Map<String, dynamic>))
          .toList();
    }

    // Tratamento para o shippingAddress
    ShippingAddressModel shippingAddr;
    if (data['shippingAddress'] != null &&
        data['shippingAddress'] is Map<String, dynamic>) {
      shippingAddr = ShippingAddressModel.fromMap(
          data['shippingAddress'] as Map<String, dynamic>);
    } else {
      // Valor padrão ou tratamento de erro se shippingAddress não for um mapa
      shippingAddr = ShippingAddressModel(
          streetAddress: 'N/A',
          city: 'N/A'
      );
    }

    return OrderModel(
      id: doc.id,
      clientId: data['clientId'] ?? 'N/A',
      creationDate: data['creationDate'] as Timestamp? ?? Timestamp.now(),
      deliveryDate: data['deliveryDate'] as Timestamp?,
      deliveryStatus: data['deliveryStatus'] ?? 'Unknown',
      items: orderItems,
      paymentMethod: data['paymentMethod'] ?? 'Pix',
      shippingAddress: shippingAddr,
      shippingCost: data['shippingCost'] ?? 0,
      total: data['total'] ?? 0,
      totalDozens: data['totalDozens'] ?? 0,
    );
  }

  // Método para converter OrderModel para um Map
  Map<String, dynamic> toFirestore() {
    return {
      'clientId': clientId,
      'creationDate': creationDate,
      'deliveryDate': deliveryDate,
      'deliveryStatus': deliveryStatus,
      'items': items.map((item) => item.toMap()).toList(),
      'paymentMethod': paymentMethod,
      'shippingAddress': shippingAddress.toMap(),
      'shippingCost': shippingCost,
      'total': total,
      'totalDozens': totalDozens,
    };
  }
}