import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/order_model.dart';

// Imports para redirecionar para o maps
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';

class OrderCard extends StatelessWidget {
  final OrderModel order;

  const OrderCard({super.key, required this.order});

  // Função para abrir o mapa
  Future<void> _launchMapsUrl(BuildContext context, String destinationAddress) async {
    String originParam = '';

    // Tenta obter a localização atual
    try {
      bool serviceEnabled;
      LocationPermission permission;

      // Testar se o serviço de localização está habilitado.
      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Serviço de localização desabilitado.')),
        );
        // Tenta abrir o mapa apenas com o destino se a localização estiver desabilitada
      } else {
        permission = await Geolocator.checkPermission();
        if (permission == LocationPermission.denied) {
          permission = await Geolocator.requestPermission();
          if (permission == LocationPermission.denied) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Permissão de localização negada.')),
            );
            // Tenta abrir o mapa apenas com o destino
          }
        }

        if (permission == LocationPermission.deniedForever) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Permissão de localização negada permanentemente. Não podemos solicitar permissões.')),
          );
          // Tenta abrir o mapa apenas com o destino
        }

        // Se tivermos permissão
        if (permission == LocationPermission.whileInUse || permission == LocationPermission.always) {
          Position position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high);
          originParam = '&saddr=${position.latitude},${position.longitude}';
        }
      }
    } catch (e) {
      print('Erro ao obter localização: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao obter localização: $e')),
      );
    }

    // Construindo a URL do Google Maps
    final String encodedDestination = Uri.encodeComponent(destinationAddress);
    String googleMapsUrl;

    if (originParam.isNotEmpty) {
      // Se obtivemos a origem
      googleMapsUrl = 'https://www.google.com/maps/dir/?api=1&origin=${originParam.replaceFirst("&saddr=", "")}&destination=$encodedDestination&travelmode=driving';
    } else {
      // Se não obtivemos a origem, abrir o mapa para direções para o destino
      googleMapsUrl = 'https://www.google.com/maps/dir/?api=1&destination=$encodedDestination&travelmode=driving';
    }

    final Uri launchUri = Uri.parse(googleMapsUrl);

    // Lançando a URL
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri, mode: LaunchMode.externalApplication);
    } else {
      print('Não foi possível abrir o Google Maps com a URL: $launchUri');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível abrir o app de mapas. Verifique se o Google Maps está instalado.')),
      );
      // Fallback: tentar uma URL mais simples apenas com o destino (sem direções)
      final Uri simplerLaunchUri = Uri.parse('https://maps.google.com/?q=$encodedDestination');
      if (await canLaunchUrl(simplerLaunchUri)) {
        await launchUrl(simplerLaunchUri, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível abrir o app de mapas.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Formating the date
    String formattedCreationDate = order.creationDate != null
        ? DateFormat('dd/MM/yyyy').format(order.creationDate.toDate())
        : 'Data não disponível';

    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[

            // Order ID and Client ID
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Pedido ID: ${order.id.substring(0, 6)}...',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).primaryColor),
                ),
                Text(
                  'Cliente ID: ${order.clientId.length > 8 ? order.clientId.substring(0, 8) + '...' : order.clientId}',
                  style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                ),
              ],
            ),
            const Divider(height: 20, thickness: 1),

            // Creation Date
            _buildInfoRow(
                icon: Icons.calendar_today,
                label: 'Data da Criação:',
                value: formattedCreationDate),
            const SizedBox(height: 8),

            // Dozens
            _buildInfoRow(
                icon: Icons.format_list_numbered, // Example icon
                label: 'Dúzias:',
                value: order.dozens.toString()),
            const SizedBox(height: 8),

            // Payment Method
            _buildInfoRow(
                icon: Icons.payment,
                label: 'Método de Pagamento:',
                value: order.paymentMethod),
            const SizedBox(height: 8),

            // Shipping Address
            _buildInfoRow(
                icon: Icons.location_on_outlined,
                label: 'Endereço de Entrega:',
                value: order.shippingAddress,
                isMultiline: true),
            const SizedBox(height: 8),

            // Total
            _buildInfoRow(
                icon: Icons.monetization_on_outlined,
                label: 'Total:',
                value: NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$')
                    .format(order.total / 100),
                valueStyle: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.green)),
            const SizedBox(height: 12),

            // Delivery Status with Chip
            Row(
              children: [
                Icon(Icons.local_shipping_outlined, color: Colors.grey[700], size: 18),
                const SizedBox(width: 8),
                Text(
                  'Status da Entrega:',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[800]),
                ),
                const Spacer(),
                Chip(
                  label: Text(
                    order.deliveryStatus,
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                  backgroundColor: _getStatusColor(order.deliveryStatus),
                  padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // BOTÃO PARA GERAR ROTA
            Center(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.directions_car_filled_outlined),
                label: const Text('Gerar Rota'),
                onPressed: () {
                  _launchMapsUrl(context, order.shippingAddress);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  foregroundColor: Theme.of(context).colorScheme.onPrimary,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 8),

          ],
        ),
      ),
    );
  }

  // Helper widget to build consistent info rows
  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
    TextStyle? valueStyle,
    bool isMultiline = false,
  }) {
    return Row(
      crossAxisAlignment:
      isMultiline ? CrossAxisAlignment.start : CrossAxisAlignment.center,
      children: [
        Icon(icon, color: Colors.grey[700], size: 18),
        const SizedBox(width: 8),
        Text(
          '$label ',
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.grey[800]),
        ),
        Expanded(
          child: Text(
            value,
            style: valueStyle ??
                TextStyle(fontSize: 14, color: Colors.grey[900]),
            textAlign: TextAlign.right,
            softWrap: isMultiline,
          ),
        ),
      ],
    );
  }

  // Helper function to determine status color
  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pendente':
        return Colors.orange.shade700;
      case 'preparando':
        return Colors.blue.shade600;
      case 'a caminho':
        return Colors.lightBlue.shade400;
      case 'concluído':
        return Colors.green.shade600;
      case 'cancelado':
        return Colors.red.shade700;
      default:
        return Colors.grey.shade500;
    }
  }
}