import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../widgets/order_card.dart';

// Firebase imports
import 'package:cloud_firestore/cloud_firestore.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key, this.title});

  final String? title;

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  @override
  Widget build(BuildContext context) {

    // Collecting the orders ordered by date
    final Stream<QuerySnapshot> ordersStream = FirebaseFirestore.instance
        .collection('orders')
        .orderBy('creationDate', descending: true)
        .snapshots();

    return Column(
      children: [

        Container(
          width: MediaQuery.of(context).size.width * 0.95,
          height: 30,
          color: Theme.of(context).primaryColor,
          margin: const EdgeInsets.only(top: 20,bottom: 20),
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.only(left: 3),
            child: Text(
              'Todos os Pedidos',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),

        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: ordersStream,
            builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {

              // Throwing errors
              if (snapshot.hasError) {
                return Center(child: Text('Algo deu errado: ${snapshot.error}'));
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              // If theres no data
              if (snapshot.data == null || snapshot.data!.docs.isEmpty) {
                return const Center(child: Text('Nenhum pedido encontrado.'));
              }

              // Building if data exists
              return ListView(
                padding: EdgeInsets.zero,
                children: snapshot.data!.docs.map((DocumentSnapshot document) {
                  OrderModel order = OrderModel.fromFirestore(document);
                  return OrderCard(order: order);
                }).toList(),
              );
            },
          ),
        ),
      ],
    );
  }
}