import 'package:flutter/material.dart';

// Firebase imports
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class ValuesScreen extends StatefulWidget {
  const ValuesScreen({super.key, this.title});

  final String? title;

  @override
  State<ValuesScreen> createState() => _ValuesScreenState();
}

class _ValuesScreenState extends State<ValuesScreen> {

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _configDocId = '1';

  // Controladores para os campos de texto
  late TextEditingController _extraValueController;
  late TextEditingController _jumboValueController;
  late TextEditingController _freeShippingController;
  late TextEditingController _shippingValueController;

  // Variáveis para armazenar os dados atuais do Firestore
  double? _currentExtraValue;
  double? _currentJumboValue;
  int? _currentFreeShipping;
  double? _currentShippingValue;

  bool _isLoading = true;
  String? _errorMessage;
  final _formKey = GlobalKey<FormState>();

  final NumberFormat _currencyFormatterUIText = NumberFormat("#,##0.00", "pt_BR");

  double? _parseCurrency(String text) {
    if (text.isEmpty) return null;
    try {
      String parsableString = text.replaceAll(RegExp(r'\.(?=.*\.)'), '').replaceAll(',', '.');
      return double.tryParse(parsableString);
    } catch (e) {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    _extraValueController = TextEditingController();
    _jumboValueController = TextEditingController();
    _freeShippingController = TextEditingController();
    _shippingValueController = TextEditingController();
    _fetchConfigurationValues();
  }

  @override
  void dispose() {
    _extraValueController.dispose();
    _jumboValueController.dispose();
    _freeShippingController.dispose();
    _shippingValueController.dispose();
    super.dispose();
  }

  // Coletando os valores que estão salvos no Firestore
  Future<void> _fetchConfigurationValues() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      DocumentSnapshot doc = await _firestore.collection('configurations').doc(_configDocId).get();
      if (doc.exists) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        setState(() {

          // Lendo INT do Firestore e convertendo para DOUBLE
          int? extraValueInt = (data['extraValue'] as num?)?.toInt();
          _currentExtraValue =
          extraValueInt != null ? extraValueInt / 100.0 : null;

          int? jumboValueInt = (data['jumboValue'] as num?)?.toInt();
          _currentJumboValue =
          jumboValueInt != null ? jumboValueInt / 100.0 : null;

          _currentFreeShipping = (data['freeShipping'] as num?)?.toInt();

          int? shippingValueInt = (data['shippingValue'] as num?)?.toInt();
          _currentShippingValue = shippingValueInt != null ? shippingValueInt / 100.0 : null;

          // Populando controllers com a string formatada
          _extraValueController.text = _currentExtraValue != null
              ? _currencyFormatterUIText.format(_currentExtraValue)
              : '';
          _jumboValueController.text = _currentJumboValue != null
              ? _currencyFormatterUIText.format(_currentJumboValue)
              : '';
          _freeShippingController.text =
              _currentFreeShipping?.toString() ?? '';
          _shippingValueController.text = _currentShippingValue != null
              ? _currencyFormatterUIText.format(_currentShippingValue)
              : '';
        });
      } else {
        setState(() {
          _errorMessage = 'Documento de configurações não encontrado.';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao buscar configurações: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Salvando os valores no Firestore
  Future<void> _saveConfigurationValues() async {

    if (!_formKey.currentState!.validate()) {
      setState(() => _isLoading = false);
      return;
    }
    if (!mounted) return;

    setState(() {
      _isLoading = true;
    });

    // Objeto para armazenar os dados a serem atualizados no Firestore
    Map<String, dynamic> dataToUpdate = {};
    bool hasChanges = false;

    // Processando Valor Unitário da Dúzia de Ovos Extra
    if (_extraValueController.text.isNotEmpty) {
      final double? newExtraValueDouble =
      _parseCurrency(_extraValueController.text);

      if (newExtraValueDouble == null || newExtraValueDouble < 0) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Novo valor unitário para Ovo Extra inválido.')),
          );
          setState(() => _isLoading = false);
        }
        return;
      }
      dataToUpdate['extraValue'] = (newExtraValueDouble * 100).round();
      _currentExtraValue = newExtraValueDouble;
      hasChanges = true;
    } else if (_currentExtraValue != null) {
      dataToUpdate['extraValue'] = 0;
      _currentExtraValue = 0;
      hasChanges = true;
    }

    // Processando Valor Unitário da Dúzia de Ovos Jumbo
    if (_jumboValueController.text.isNotEmpty) {
      final double? newJumboValueDouble =
      _parseCurrency(_jumboValueController.text);

      if (newJumboValueDouble == null || newJumboValueDouble < 0) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Novo valor unitário para Ovo Jumbo inválido.')),
          );
          setState(() => _isLoading = false);
        }
        return;
      }
      dataToUpdate['jumboValue'] = (newJumboValueDouble * 100).round();
      _currentJumboValue = newJumboValueDouble;
      hasChanges = true;
    } else if (_currentJumboValue != null) {
      dataToUpdate['jumboValue'] = 0;
      _currentJumboValue = 0;
      hasChanges = true;
    }

    // Processando Dúzias para Frete Grátis
    if (_freeShippingController.text.isNotEmpty) {
      final int? newFreeShipping = int.tryParse(_freeShippingController.text);
      if (newFreeShipping == null || newFreeShipping < 0) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Novo valor para dúzias de frete grátis inválido.')),
          );
          setState(() => _isLoading = false);
        }
        return;
      }
      dataToUpdate['freeShipping'] = newFreeShipping;
      _currentFreeShipping = newFreeShipping;
      hasChanges = true;
    }

    // Processando Valor do Frete
    if (_shippingValueController.text.isNotEmpty) {
      final double? newShippingValueDouble = _parseCurrency(_shippingValueController.text);
      if (newShippingValueDouble == null || newShippingValueDouble < 0) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Novo valor do frete inválido.')),
          );
          setState(() => _isLoading = false);
        }
        return;
      }
      // Converter para int
      dataToUpdate['shippingValue'] = (newShippingValueDouble * 100).round();
      _currentShippingValue = newShippingValueDouble;
      hasChanges = true;
    }

    // Só salvar se houver algo para atualizar
    if (!hasChanges && dataToUpdate.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nenhuma alteração para salvar.')),
        );
        setState(() => _isLoading = false);
      }
      FocusScope.of(context).unfocus();
      return;
    }

    // Caso não há o que atualizar
    if (dataToUpdate.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nenhum valor novo ou existente para salvar.')),
        );
        setState(() => _isLoading = false);
      }
      FocusScope.of(context).unfocus();
      return;
    }


    try {
      await _firestore
          .collection('configurations')
          .doc(_configDocId)
          .update(dataToUpdate);

      await _fetchConfigurationValues();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Configurações salvas com sucesso!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao salvar configurações: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        FocusScope.of(context).unfocus();
      }
    }
  }

  Widget _buildConfigSectionHeader(String title) {
    return Container(
      width: MediaQuery
          .of(context)
          .size
          .width * 0.95,
      height: 30,
      color: Theme
          .of(context)
          .primaryColor,
      margin: const EdgeInsets.only(top: 20, bottom: 10),
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: const EdgeInsets.only(left: 10),
        child: Text(
          title,
          style: TextStyle(
            color: Theme
                .of(context)
                .colorScheme
                .onPrimary,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    String? currentValueText,
    TextInputType keyboardType = TextInputType.number,
    String? prefixText,
    String? hintText,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (currentValueText != null && currentValueText.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 4.0),
              child: Text(
                currentValueText,
                style: TextStyle(
                  fontSize: 14,
                  color: Theme.of(context).hintColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          TextFormField(
            controller: controller,
            decoration: InputDecoration(
              labelText: label,
              prefixText: prefixText,
              hintText: hintText ?? '0,00',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
              filled: true,
              fillColor: Colors.white,
            ),
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            validator: validator,
            style: const TextStyle(color: Colors.black87),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading && _currentExtraValue == null && _currentJumboValue == null) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_errorMessage!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red, fontSize: 16)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchConfigurationValues,
                child: const Text('Tentar Novamente'),
              ),
            ],
          ),
        ),
      );
    }

    return Stack(
      children: [
        GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  _buildConfigSectionHeader('Opções para Dúzias'),
                  _buildTextField(
                    controller: _extraValueController,
                    label: 'Novo Valor Ovo Extra',
                    currentValueText: _currentExtraValue != null
                        ? 'Valor Atual Ovo Extra: R\$ ${_currencyFormatterUIText.format(_currentExtraValue)}'
                        : 'Valor Atual Ovo Extra: Não definido',
                    prefixText: 'R\$ ',
                    keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(
                          RegExp(r'^\d*[,]?\d{0,2}')),
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) return null;
                      final val = _parseCurrency(value);
                      if (val == null || val < 0) {
                        return 'Novo valor inválido';
                      }
                      return null;
                    },
                  ),

                  _buildTextField(
                    controller: _jumboValueController,
                    label: 'Novo Valor Ovo Jumbo',
                    currentValueText: _currentJumboValue != null
                        ? 'Valor Atual Ovo Jumbo: R\$ ${_currencyFormatterUIText.format(_currentJumboValue)}'
                        : 'Valor Atual Ovo Jumbo: Não definido',
                    prefixText: 'R\$ ',
                    keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(
                          RegExp(r'^\d*[,]?\d{0,2}')),
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) return null;
                      final val = _parseCurrency(value);
                      if (val == null || val < 0) {
                        return 'Novo valor inválido';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 20),
                  _buildConfigSectionHeader('Opções para Frete'),
                  _buildTextField(
                    controller: _freeShippingController,
                    label: 'Novas Dúzias p/ Frete Grátis',
                    currentValueText: _currentFreeShipping != null
                        ? 'Atual: ${_currentFreeShipping} dúzias'
                        : 'Atual: Não definido',
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) return null;
                      final val = int.tryParse(value);
                      if (val == null || val < 0) {
                        return 'Novo valor inválido';
                      }
                      return null;
                    },
                  ),

                  _buildTextField(
                    controller: _shippingValueController,
                    label: 'Novo Valor do Frete Padrão',
                    currentValueText: _currentShippingValue != null
                        ? 'Valor Atual: R\$ ${_currencyFormatterUIText.format(_currentShippingValue)}'
                        : 'Valor Atual: Não definido',
                    prefixText: 'R\$ ',
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'^\d*[,]?\d{0,2}')),
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) return null;
                      final val = _parseCurrency(value);
                      if (val == null || val < 0) {
                        return 'Novo valor inválido';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: _isLoading
                        ? null
                        : () {
                          // Validar o formulário antes de salvar
                          if (_formKey.currentState!.validate()) {
                            _saveConfigurationValues();
                          }
                        },
                    child: const Text('Salvar Configurações'),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),

        if (_isLoading)
          Container(
            color: Colors.black.withOpacity(0.3),
            child: const Center(
              child: CircularProgressIndicator(),
            ),
          ),
      ],
    );
  }
}