import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/order_model.dart';

// Imports para redirecionar para o maps
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';

class OrderCard extends StatelessWidget {
  final OrderModel order;

  const OrderCard({super.key, required this.order});

  // Função para abrir o mapa
  Future<void> _launchMapsUrl(BuildContext context, String destinationAddress) async {
    String originParam = '';

    try {
      bool serviceEnabled;
      LocationPermission permission;

      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Serviço de localização desabilitado.')),
        );
      } else {
        permission = await Geolocator.checkPermission();
        if (permission == LocationPermission.denied) {
          permission = await Geolocator.requestPermission();
          if (permission == LocationPermission.denied) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Permissão de localização negada.')),
            );
          }
        }

        if (permission == LocationPermission.deniedForever) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text(
                'Permissão de localização negada permanentemente. Não podemos solicitar permissões.')),
          );
        }

        if (permission == LocationPermission.whileInUse ||
            permission == LocationPermission.always) {
          try {
            // Declare a variável settings separadamente

            Position position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high,
            );
            originParam = '&saddr=${position.latitude},${position.longitude}';
          } catch (e) {
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                    content: Text('Não foi possível obter a localização: $e')),
              );
            }
          }
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao obter localização: $e')),
      );
    }

    final String encodedDestination = Uri.encodeComponent(destinationAddress);
    String googleMapsUrl;

    if (originParam.isNotEmpty) {
      googleMapsUrl = 'https://www.google.com/maps/dir/?api=1&origin=${originParam.replaceFirst("&saddr=", "")}&destination=$encodedDestination&travelmode=driving';
    } else {
      googleMapsUrl = 'https://www.google.com/maps/dir/?api=1&destination=$encodedDestination&travelmode=driving';
    }

    final Uri launchUri = Uri.parse(googleMapsUrl);

    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível abrir o app de mapas. Verifique se o Google Maps está instalado.')),
      );
      final Uri simplerLaunchUri = Uri.parse('https://maps.google.com/?q=$encodedDestination');
      if (await canLaunchUrl(simplerLaunchUri)) {
        await launchUrl(simplerLaunchUri, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível abrir o app de mapas.')),
        );
      }
    }
  }

  // Helper para formatar o endereço a partir do ShippingAddressModel
  String _getFormattedShippingAddress(ShippingAddressModel address) {

    List<String> parts = [];
    if (address.businessName != null && address.businessName!.isNotEmpty) {
      parts.add(address.businessName!);
    }
    if (address.streetAddress != null && address.streetAddress!.isNotEmpty) {
      parts.add(address.streetAddress!);
    }
    if (address.city != null && address.city!.isNotEmpty) {
      parts.add(address.city!);
    }
    if (address.adminArea != null && address.adminArea!.isNotEmpty) {
      parts.add(address.adminArea!);
    }
    if (address.zipCode != null && address.zipCode!.isNotEmpty) {
      parts.add(address.zipCode!);
    }
    if (parts.isEmpty) {
      return 'Endereço não disponível';
    }
      return parts.join(', ');
  }


  @override
  Widget build(BuildContext context) {
    String formattedCreationDate = DateFormat('dd/MM/yyyy').format(order.creationDate.toDate());

    // Obter a string formatada do endereço
    String displayShippingAddress = _getFormattedShippingAddress(order.shippingAddress);

    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(
                    'Pedido ID: ${order.id.length > 6 ? order.id.substring(0, 6) : order.id}...',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).primaryColor),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Flexible(
                  child: Text(
                    'Cliente ID: ${order.clientId.length > 8 ? order.clientId.substring(0, 8) + '...' : order.clientId}',
                    style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const Divider(height: 20, thickness: 1),

            _buildInfoRow(
                icon: Icons.calendar_today,
                label: 'Data da Criação:',
                value: formattedCreationDate),
            const SizedBox(height: 8),

            // Dúzias usando totalDozens
            _buildInfoRow(
                icon: Icons.format_list_numbered,
                label: 'Total de Dúzias:',
                value: order.totalDozens.toString()),
            const SizedBox(height: 8),

             ...order.items.map((item) => Padding(
               padding: const EdgeInsets.only(bottom: 4.0),
               child: _buildInfoRow(
                 icon: Icons.egg_outlined,
                 label: 'Item (${item.type}):',
                 value: '${item.quantity} dúzia(s)',
               ),
             )).toList(),
             if (order.items.isNotEmpty) const SizedBox(height: 8),

            _buildInfoRow(
                icon: Icons.payment,
                label: 'Método de Pagamento:',
                value: order.paymentMethod),
            const SizedBox(height: 8),

            // Endereço de Entrega
            _buildInfoRow(
                icon: Icons.location_on_outlined,
                label: 'Endereço de Entrega:',
                value: displayShippingAddress,
                isMultiline: true),
            const SizedBox(height: 8),

            _buildInfoRow(
                icon: Icons.monetization_on_outlined,
                label: 'Total:',
                value: NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$')
                    .format(order.total / 100),
                valueStyle: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.green)),
            const SizedBox(height: 12),

            Row(
              children: [
                Icon(Icons.local_shipping_outlined, color: Colors.grey[700], size: 18),
                const SizedBox(width: 8),
                Text(
                  'Status da Entrega:',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[800]),
                ),
                const Spacer(),
                Chip(
                  label: Text(
                    order.deliveryStatus,
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                  backgroundColor: _getStatusColor(order.deliveryStatus),
                  padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Center(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.directions_car_filled_outlined),
                label: const Text('Gerar Rota'),
                onPressed: () {
                  _launchMapsUrl(context, displayShippingAddress);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  foregroundColor: Theme.of(context).colorScheme.onPrimary,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
    TextStyle? valueStyle,
    bool isMultiline = false,
  }) {
    return Row(
      crossAxisAlignment:
      isMultiline ? CrossAxisAlignment.start : CrossAxisAlignment.center,
      children: [
        Icon(icon, color: Colors.grey[700], size: 18),
        const SizedBox(width: 8),
        Text(
          '$label ',
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.grey[800]),
        ),
        Expanded(
          child: Text(
            value,
            style: valueStyle ??
                TextStyle(fontSize: 14, color: Colors.grey[900]),
            textAlign: TextAlign.right,
            softWrap: isMultiline,
            overflow: isMultiline ? TextOverflow.visible : TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pendente':
        return Colors.orange.shade700;
      case 'preparando':
        return Colors.blue.shade600;
      case 'a caminho':
        return Colors.lightBlue.shade400;
      case 'concluído':
        return Colors.green.shade600;
      case 'cancelado':
        return Colors.red.shade700;
      default:
        return Colors.grey.shade500;
    }
  }
}